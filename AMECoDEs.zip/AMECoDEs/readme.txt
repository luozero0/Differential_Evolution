 now, only original algorithm is revised.
30D 10times 2017